# Atlas TCG — projeto inicial v0.1

## O que esta pronto
- `gamefile.json`: primeira distribuicao de zonas baseada no desenho enviado; contem um botao para comprar carta e marcador manual de rodada.
- `cards.json`: duas cartas FICTICIAS de teste, nao sao cartas oficiais do Atlas.
- `assets/`: imagens provisórias (substitua pelas artes reais das suas cartas).
- `scripts/regras-atlas.js`: validacao do custo por descarte, calculo da defesa e comparacao de velocidade, ainda SEM ligacao com os eventos do TCG Arena.
- `scripts/testar-regras.js`: testes locais para a logica acima.

## Limitacoes atuais
- O projeto foi validado como JSON e com testes JavaScript locais, MAS ainda nao foi carregado no TCG Arena. Ajustes no layout podem ser necessarios.
- O custo colorido fica em `atlas.custo`, campo proprio do nosso projeto; o TCG Arena ainda nao executa automaticamente o pagamento.
- O pagamento das cartas, os 4 espacos de batalha, defesa, eliminacao, desempate d6, efeitos, construcoes e validacao de decks ainda precisam de integracao adicional.
- Mao inicial (5), compra por turno (1), atributos e custos das cartas de EXEMPLO sao valores PROVISORIOS. Nao sao regras confirmadas.
- O Reino e Comandante ficaram como zonas; as restricoes exatas de montagem do deck serao implementadas posteriormente.

## Como publicar para teste
1. Crie um repositorio publico `atlas-tcg` no GitHub e envie o CONTEUDO desta pasta para a raiz do repositorio.
2. Ative GitHub Pages nas configuracoes do repositorio (branch main, diretorio /root).
3. No `gamefile.json`, substitua `SEU-USUARIO` em `cards.dataUrl` e `cards.cardBack` pelo seu usuario GitHub.
4. No `cards.json`, substitua `SEU-USUARIO` em cada `image` pelo seu usuario GitHub.
5. Confirme que `https://SEU-USUARIO.github.io/atlas-tcg/gamefile.json` e `.../cards.json` abrem no navegador.
6. No TCG Arena, carregue o URL publico do `gamefile.json` pelo fluxo de adicionar/carregar jogo personalizado da plataforma.
7. Teste as zonas e os controles. Se aparecer erro, salve a mensagem para ajustarmos.

## Testes locais
Com Node.js instalado, execute `node scripts/testar-regras.js`.

## Referencias
https://documentation.tcg-arena.fr/
https://documentation.tcg-arena.fr/sections
https://documentation.tcg-arena.fr/content-files
https://documentation.tcg-arena.fr/scripting
